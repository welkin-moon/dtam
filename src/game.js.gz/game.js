(() => {
'use strict';

const MAX_PLAYERS = 15;
const MAP_SIZE = 150;
const VIEW_TILES = 20;
const PLAYER_RADIUS = 0.32;
const MOVE_SPEED = 4.6;
const POS_SEND_INTERVAL = 50;
const HEARTBEAT_INTERVAL = 15000;
const STALE_SOCKET_MS = 45000;
const REMOTE_SMOOTHING = 18;
const REALTIME_ORIGIN = 'wss://rt-d1.lunarlab.uk';
const COLORS = [
  '#ef4444','#f97316','#eab308','#84cc16','#22c55e','#10b981','#14b8a6','#06b6d4',
  '#3b82f6','#6366f1','#8b5cf6','#a855f7','#d946ef','#f43f5e','#ec4899'
];
const OBJECT_DEFS = [
  { id:'power-nw', x:7.5, y:7.5, label:'西北配电箱' },
  { id:'relay-n', x:42.5, y:7.5, label:'北区中继器' },
  { id:'sensor-ne', x:92.5, y:7.5, label:'东北传感器' },
  { id:'gate-e', x:142.5, y:32.5, label:'东侧门禁' },
  { id:'pump-w', x:7.5, y:57.5, label:'西区水泵' },
  { id:'console-c1', x:67.5, y:57.5, label:'中央控制台 A' },
  { id:'console-c2', x:82.5, y:92.5, label:'中央控制台 B' },
  { id:'radio-e', x:142.5, y:82.5, label:'东区无线电' },
  { id:'beacon-sw', x:17.5, y:117.5, label:'西南信标' },
  { id:'panel-s', x:67.5, y:142.5, label:'南区面板' },
  { id:'relay-se', x:117.5, y:142.5, label:'东南中继器' },
  { id:'gate-s', x:142.5, y:117.5, label:'南侧门禁' }
];
const EMERGENCY_STATION = 'console-c1';

function buildMap() {
  const map = new Uint8Array(MAP_SIZE * MAP_SIZE);
  const setWall = (x,y,v=1) => { if (x>=0&&x<MAP_SIZE&&y>=0&&y<MAP_SIZE) map[y*MAP_SIZE+x]=v; };
  for (let i=0;i<MAP_SIZE;i++){setWall(i,0);setWall(i,MAP_SIZE-1);setWall(0,i);setWall(MAP_SIZE-1,i);}
  const lines=[25,50,75,100,125];
  lines.forEach((x,li)=>{for(let y=1;y<MAP_SIZE-1;y++){const sector=Math.floor(y/25),local=y%25;const ds=((sector+li)%2===0)?6:16;if(local<ds||local>ds+2)setWall(x,y);}});
  lines.forEach((y,li)=>{for(let x=1;x<MAP_SIZE-1;x++){const sector=Math.floor(x/25),local=x%25;const ds=((sector+li+1)%2===0)?6:16;if(local<ds||local>ds+2)setWall(x,y);}});
  for(let sy=0;sy<6;sy++)for(let sx=0;sx<6;sx++){
    if(sx===3&&sy===3)continue;if((sx+sy)%2!==0)continue;
    const cx=sx*25+13,cy=sy*25+13,horizontal=((sx*3+sy)%2)===0,w=horizontal?5:2,h=horizontal?2:5;
    for(let oy=-Math.floor(h/2);oy<=Math.floor(h/2);oy++)for(let ox=-Math.floor(w/2);ox<=Math.floor(w/2);ox++)setWall(cx+ox,cy+oy);
  }
  for(let y=70;y<=80;y++)for(let x=70;x<=80;x++)setWall(x,y,0);
  for(const obj of OBJECT_DEFS){const cx=Math.floor(obj.x),cy=Math.floor(obj.y);for(let y=cy-1;y<=cy+1;y++)for(let x=cx-1;x<=cx+1;x++)setWall(x,y,0);}
  return map;
}
const MAP_DATA=buildMap();

const $=id=>document.getElementById(id);
const menu=$('menu'),game=$('game'),canvas=$('canvas'),ctx=canvas.getContext('2d');
const nameInput=$('playerNameInput'),createBtn=$('createRoomBtn'),showJoinBtn=$('showJoinBtn'),joinSection=$('joinSection');
const roomIdInput=$('roomIdInput'),joinBtn=$('joinRoomBtn'),menuStatus=$('menuStatus'),roomIdDisplay=$('roomIdDisplay');
const playerCountNum=$('playerCountNum'),hudMyName=$('hudMyName'),leaveBtn=$('leaveBtn'),gameToast=$('gameToast');
const leaveNotice=$('leaveNotice'),joystick=$('joystick'),joystickKnob=$('joystickKnob'),chatToggle=$('chatToggle');
const chatPanel=$('chatPanel'),chatPanelMessages=$('chatPanelMessages'),chatStream=$('chatStream'),chatInput=$('chatInput');
const chatSend=$('chatSend'),chatPanelClose=$('chatPanelClose'),rotateOverlay=$('rotateOverlay'),playerPanel=$('playerPanel');
const playerPanelBody=$('playerPanelBody'),playerPanelClose=$('playerPanelClose'),playerCountBtn=$('playerCountBtn');
const settingsBtn=$('settingsBtn'),menuThemeBtn=$('menuThemeBtn'),interactBtn=$('interactBtn'),connectionStatus=$('connectionStatus');

function injectGameplayUI(){
  const meta=document.createElement('div');meta.id='gameMeta';meta.innerHTML=`
    <div class="meta-line"><span id="phaseLabel">大厅</span><span id="roleLabel">等待开始</span></div>
    <div id="taskProgressWrap"><div id="taskProgress"></div></div>
    <div id="taskText">等待房主开始游戏</div>`;game.appendChild(meta);
  const lobby=document.createElement('div');lobby.id='lobbyPanel';lobby.innerHTML=`
    <div class="lobby-title">房间大厅</div><div class="lobby-sub" id="lobbyHint">等待玩家加入</div>
    <button type="button" id="startGameBtn">开始游戏</button>`;game.appendChild(lobby);
  const action=document.createElement('div');action.id='actionStack';action.innerHTML=`
    <button type="button" id="reportBtn" disabled>报告</button>
    <button type="button" id="killBtn" disabled>击杀</button>`;game.appendChild(action);
  const role=document.createElement('div');role.id='roleReveal';role.innerHTML=`<div class="role-card"><div class="eyebrow">你的身份</div><div id="roleRevealName"></div><div id="roleRevealDesc"></div></div>`;game.appendChild(role);
  const meeting=document.createElement('div');meeting.id='meetingOverlay';meeting.innerHTML=`
    <div class="meeting-card"><div class="meeting-head"><div><div class="eyebrow">会议</div><h2 id="meetingTitle">讨论</h2></div><div id="meetingTimer">--</div></div>
    <div id="meetingBody"></div><div id="voteGrid"></div><div class="meeting-actions"><button id="skipVoteBtn" type="button">跳过投票</button></div></div>`;game.appendChild(meeting);
  const end=document.createElement('div');end.id='endOverlay';end.innerHTML=`<div class="end-card"><div class="eyebrow">本局结束</div><h2 id="endTitle"></h2><p id="endReason"></p><button type="button" id="backLobbyBtn">返回大厅</button></div>`;game.appendChild(end);
  const taskModal=document.createElement('div');taskModal.id='taskModal';taskModal.innerHTML=`<div class="task-card"><div class="eyebrow">任务</div><h2 id="taskModalTitle">处理设施</h2><p>保持操作直到进度完成。</p><div class="task-meter"><div id="taskMeterFill"></div></div><button type="button" id="taskHoldBtn">按住处理</button><button type="button" id="taskCancelBtn" class="ghost">取消</button></div>`;game.appendChild(taskModal);
}
injectGameplayUI();
const phaseLabel=$('phaseLabel'),roleLabel=$('roleLabel'),taskProgress=$('taskProgress'),taskText=$('taskText');
const lobbyPanel=$('lobbyPanel'),lobbyHint=$('lobbyHint'),startGameBtn=$('startGameBtn'),reportBtn=$('reportBtn'),killBtn=$('killBtn');
const roleReveal=$('roleReveal'),roleRevealName=$('roleRevealName'),roleRevealDesc=$('roleRevealDesc');
const meetingOverlay=$('meetingOverlay'),meetingTitle=$('meetingTitle'),meetingTimer=$('meetingTimer'),meetingBody=$('meetingBody');
const voteGrid=$('voteGrid'),skipVoteBtn=$('skipVoteBtn'),endOverlay=$('endOverlay'),endTitle=$('endTitle'),endReason=$('endReason');
const backLobbyBtn=$('backLobbyBtn'),taskModal=$('taskModal'),taskModalTitle=$('taskModalTitle'),taskMeterFill=$('taskMeterFill');
const taskHoldBtn=$('taskHoldBtn'),taskCancelBtn=$('taskCancelBtn');

let socket=null,socketGeneration=0,intentionalClose=false,currentRoom='',resumeToken='',myPlayerId='',myName='玩家',isHost=false;
let players={},remoteVisuals={},myPos={x:75.5,y:75.5},messages=[],bodies=[];
let gameState={phase:'lobby',winner:'',reason:'',taskDone:0,taskTotal:0,meeting:null};
let selfState={role:'',alive:true,tasks:[],completed:[],killReadyAt:0,emergencyUsed:0};
let chatVisible=false,playerPanelVisible=false,keys={},joyActive=false,joyDX=0,joyDY=0,mouseDown=false;
let lastFrameTime=performance.now(),lastPosSendTime=0,posDirty=false,reconnectAttempts=0,reconnectTimer=null,heartbeatTimer=null,lastPongAt=Date.now();
let connectResolve=null,connectReject=null,connectTimeout=null,toastTimer=null,leaveNoticeTimer=null,joinVisible=false,meetingTickTimer=null;
let activeTaskId='',taskHoldStart=0,taskHoldRAF=0;

const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
const sanitizeName=v=>{const t=String(v??'').replace(/[\u0000-\u001f\u007f]/g,'').trim();return(t||'玩家').slice(0,12);};
const sanitizeChatText=v=>String(v??'').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g,'').trim().slice(0,100);
const escapeHtml=v=>String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const generateRoomId=()=>String(Math.floor(100000+Math.random()*900000));
function isWallCell(c,r){if(c<0||r<0||c>=MAP_SIZE||r>=MAP_SIZE)return true;return MAP_DATA[r*MAP_SIZE+c]===1;}
function circleHitsWall(x,y,r=PLAYER_RADIUS){const minX=Math.floor(x-r),maxX=Math.floor(x+r),minY=Math.floor(y-r),maxY=Math.floor(y+r);for(let row=minY;row<=maxY;row++)for(let col=minX;col<=maxX;col++){if(!isWallCell(col,row))continue;const nx=clamp(x,col,col+1),ny=clamp(y,row,row+1),dx=x-nx,dy=y-ny;if(dx*dx+dy*dy<r*r)return true;}return false;}
function objById(id){return OBJECT_DEFS.find(o=>o.id===id)||null;}
function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y);}

function applyTheme(theme,persist=true){document.documentElement.dataset.theme=theme;if(persist)try{localStorage.setItem('au-theme',theme);}catch(_){}const label=theme==='dark'?'浅色':'深色';menuThemeBtn.textContent=label;settingsBtn.textContent=label;}
function getInitialTheme(){try{const s=localStorage.getItem('au-theme');if(s==='light'||s==='dark')return s;}catch(_){}return document.documentElement.dataset.theme||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');}
function toggleTheme(){applyTheme((document.documentElement.dataset.theme||getInitialTheme())==='dark'?'light':'dark');}applyTheme(getInitialTheme(),false);
function setConnectionState(state,text){connectionStatus.dataset.state=state;connectionStatus.textContent=text;}
function setMenuStatus(text,type=''){menuStatus.textContent=text;menuStatus.className=type;}
function showToast(text,duration=1700){clearTimeout(toastTimer);gameToast.textContent=text;gameToast.classList.add('show');toastTimer=setTimeout(()=>gameToast.classList.remove('show'),duration);}
function showLeaveNotice(text){clearTimeout(leaveNoticeTimer);leaveNotice.textContent=text;leaveNotice.style.opacity='1';leaveNoticeTimer=setTimeout(()=>leaveNotice.style.opacity='0',1800);}
function checkOrientation(){rotateOverlay.classList.toggle('show',innerWidth<720&&innerHeight>innerWidth);}
function showMenu(){menu.style.display='flex';game.style.display='none';window._gameLoopRunning=false;}
function showGame(){menu.style.display='none';game.style.display='block';checkOrientation();resizeCanvas();}
function enterGame(){showGame();hudMyName.textContent=myName;roomIdDisplay.textContent=currentRoom;renderAllUI();lastFrameTime=performance.now();if(!window._gameLoopRunning){window._gameLoopRunning=true;requestAnimationFrame(gameLoop);}}
function sessionKey(room){return`au-dtam-session:${room}`;}
function loadResumeToken(room){try{return sessionStorage.getItem(sessionKey(room))||'';}catch(_){return'';}}
function saveResumeToken(room,token){try{sessionStorage.setItem(sessionKey(room),token);}catch(_){} }
function clearResumeToken(room){try{sessionStorage.removeItem(sessionKey(room));}catch(_){} }

function normalizePlayers(raw){const out={};for(const p of Array.isArray(raw)?raw:Object.values(raw||{})){if(!p?.id)continue;out[String(p.id)]={id:String(p.id),name:sanitizeName(p.name),color:COLORS.includes(p.color)?p.color:COLORS[0],pos:{x:Number(p.pos?.x)||75.5,y:Number(p.pos?.y)||75.5},isHost:!!p.isHost,connected:p.connected!==false,alive:p.alive!==false};}return out;}
function seedRemoteVisuals(){remoteVisuals={};for(const p of Object.values(players)){if(p.id===myPlayerId)continue;remoteVisuals[p.id]={x:p.pos.x,y:p.pos.y,targetX:p.pos.x,targetY:p.pos.y};}}
function retargetRemote(id,x,y){if(id===myPlayerId)return;const v=remoteVisuals[id];if(v){v.targetX=x;v.targetY=y;}else remoteVisuals[id]={x,y,targetX:x,targetY:y};}
function updateRemoteVisuals(dt){const a=1-Math.exp(-REMOTE_SMOOTHING*clamp(dt,0,0.05));for(const v of Object.values(remoteVisuals)){v.x+=(v.targetX-v.x)*a;v.y+=(v.targetY-v.y)*a;}}

function renderPlayerCount(){playerCountNum.textContent=String(Object.keys(players).length||1);if(playerPanelVisible)renderPlayerPanel();}
function renderPlayerPanel(){const list=Object.values(players).sort((a,b)=>(b.isHost?1:0)-(a.isHost?1:0)||a.name.localeCompare(b.name));playerPanelBody.innerHTML=list.map(p=>{const me=p.id===myPlayerId,canKick=isHost&&!me&&gameState.phase==='lobby';return`<div class="player-row ${p.alive?'':'dead-row'}"><span class="color-dot" style="background:${escapeHtml(p.color)}"></span><span class="player-name">${escapeHtml(p.name)}${me?' · 你':''}${p.connected?'':' · 离线'}</span>${p.isHost?'<span class="host-badge">房主</span>':''}${!p.alive?'<span class="dead-badge">死亡</span>':''}${canKick?`<button type="button" class="kick-btn" data-player-id="${escapeHtml(p.id)}">移出</button>`:''}</div>`;}).join('')||'<div class="empty-msg">暂无玩家</div>';playerPanelBody.querySelectorAll('.kick-btn').forEach(btn=>btn.onclick=()=>kickPlayer(btn.dataset.playerId));}
function togglePlayerPanel(force){playerPanelVisible=typeof force==='boolean'?force:!playerPanelVisible;playerPanel.classList.toggle('open',playerPanelVisible);playerCountBtn.setAttribute('aria-expanded',String(playerPanelVisible));if(playerPanelVisible)renderPlayerPanel();}
function addMessage(name,text,time=Date.now()){const clean=sanitizeChatText(text);if(!clean)return;messages.push({name:sanitizeName(name),text:clean,time});if(messages.length>80)messages.splice(0,messages.length-80);renderChatMessages();}
function renderChatMessages(){const rows=messages.map(m=>`<div class="msg-item"><span class="msg-name">${escapeHtml(m.name)}</span><span class="msg-text">${escapeHtml(m.text)}</span></div>`).join('');const html=rows||'<div class="empty-msg">暂无消息</div>';chatPanelMessages.innerHTML=html;chatStream.innerHTML=messages.slice(-3).map(m=>`<div class="msg-item"><span class="msg-name">${escapeHtml(m.name)}</span><span class="msg-text">${escapeHtml(m.text)}</span></div>`).join('')||'<div class="empty-msg">暂无消息</div>';chatPanelMessages.scrollTop=chatPanelMessages.scrollHeight;}
function toggleChat(force){chatVisible=typeof force==='boolean'?force:!chatVisible;chatPanel.classList.toggle('open',chatVisible);chatPanel.setAttribute('aria-hidden',String(!chatVisible));chatToggle.setAttribute('aria-expanded',String(chatVisible));if(chatVisible)setTimeout(()=>chatInput.focus(),0);}

function renderAllUI(){renderPlayerCount();renderPlayerPanel();renderChatMessages();renderGameMeta();renderLobby();renderActions();}
function renderGameMeta(){phaseLabel.textContent=({lobby:'大厅',playing:'进行中',meeting:'会议',ended:'已结束'})[gameState.phase]||gameState.phase;if(gameState.phase==='lobby')roleLabel.textContent='等待开始';else if(selfState.role==='impostor')roleLabel.textContent=selfState.alive?'内鬼':'内鬼 · 已死亡';else if(selfState.role==='crewmate')roleLabel.textContent=selfState.alive?'船员':'船员 · 幽灵';else roleLabel.textContent='观战';const pct=gameState.taskTotal?clamp(gameState.taskDone/gameState.taskTotal*100,0,100):0;taskProgress.style.width=`${pct}%`;if(gameState.phase==='lobby')taskText.textContent='等待房主开始游戏';else if(gameState.phase==='ended')taskText.textContent=gameState.reason||'本局结束';else if(selfState.role==='crewmate'){const remaining=selfState.tasks.filter(id=>!selfState.completed.includes(id));taskText.textContent=remaining.length?`剩余任务 ${remaining.length} · ${remaining.map(id=>objById(id)?.label).filter(Boolean).slice(0,2).join(' / ')}`:'你的任务已全部完成';}else if(selfState.role==='impostor')taskText.textContent=selfState.alive?'接近船员后可击杀；利用会议误导其他人':'你已死亡，等待本局结束';}
function renderLobby(){const visible=gameState.phase==='lobby';lobbyPanel.classList.toggle('show',visible);if(!visible)return;const count=Object.keys(players).length;lobbyHint.textContent=isHost?`当前 ${count} 人 · 至少 2 人即可开始`:'等待房主开始游戏';startGameBtn.style.display=isHost?'block':'none';startGameBtn.disabled=count<2;}
function nearestBody(){if(!selfState.alive||gameState.phase!=='playing')return null;let best=null,bestD=1.55;for(const b of bodies){const d=Math.hypot(myPos.x-b.x,myPos.y-b.y);if(d<bestD){best=b;bestD=d;}}return best;}
function nearestKillTarget(){if(selfState.role!=='impostor'||!selfState.alive||gameState.phase!=='playing')return null;let best=null,bestD=1.12;for(const p of Object.values(players)){if(p.id===myPlayerId||!p.alive||!p.connected)continue;const v=remoteVisuals[p.id],pos=v?{x:v.x,y:v.y}:p.pos;const d=dist(myPos,pos);if(d<bestD){best=p;bestD=d;}}return best;}
function nearestAssignedTask(){if(selfState.role!=='crewmate'||gameState.phase!=='playing')return null;let best=null,bestD=1.45;for(const id of selfState.tasks){if(selfState.completed.includes(id))continue;const o=objById(id);if(!o)continue;const d=dist(myPos,o);if(d<bestD){best=o;bestD=d;}}return best;}
function canEmergency(){if(!selfState.alive||gameState.phase!=='playing'||selfState.emergencyUsed>0)return false;const o=objById(EMERGENCY_STATION);return o&&dist(myPos,o)<1.5;}
function renderActions(){const playing=gameState.phase==='playing';const body=nearestBody(),target=nearestKillTarget(),task=nearestAssignedTask();reportBtn.disabled=!body;reportBtn.textContent=body?'报告尸体':'报告';const cooldown=Math.max(0,Math.ceil((selfState.killReadyAt-Date.now())/1000));killBtn.style.display=selfState.role==='impostor'?'block':'none';killBtn.disabled=!target||cooldown>0||!playing;killBtn.textContent=cooldown>0?`击杀 ${cooldown}s`:(target?`击杀 ${target.name}`:'击杀');if(gameState.phase!=='playing'){interactBtn.disabled=true;interactBtn.textContent='互动';return;}if(task){interactBtn.disabled=false;interactBtn.textContent='执行任务';interactBtn.title=task.label;}else if(canEmergency()){interactBtn.disabled=false;interactBtn.textContent='紧急会议';interactBtn.title='呼叫紧急会议';}else{interactBtn.disabled=true;interactBtn.textContent=selfState.alive?'互动':'幽灵';interactBtn.title='靠近任务或中央控制台';}}

function sendPacket(payload){if(!socket||socket.readyState!==WebSocket.OPEN)return false;socket.send(JSON.stringify(payload));return true;}
function sendChatMessage(value){const text=sanitizeChatText(value);if(!text)return;if(gameState.phase==='playing'){showToast('游戏进行中不可聊天，会议时再发言');return;}if(!sendPacket({t:'chat',text})){showToast('正在重连，消息未发送');return;}chatInput.value='';}
function kickPlayer(id){if(!isHost||gameState.phase!=='lobby'||!players[id])return;if(confirm(`确定移出 ${players[id].name} 吗？`))sendPacket({t:'kick',id});}
function startHeartbeat(){clearInterval(heartbeatTimer);lastPongAt=Date.now();heartbeatTimer=setInterval(()=>{if(!socket||socket.readyState!==WebSocket.OPEN)return;if(document.visibilityState==='visible'&&Date.now()-lastPongAt>STALE_SOCKET_MS){try{socket.close(4001,'stale');}catch(_){}return;}sendPacket({t:'ping',at:Date.now()});},HEARTBEAT_INTERVAL);}
function stopHeartbeat(){clearInterval(heartbeatTimer);heartbeatTimer=null;}

function showRoleReveal(){roleRevealName.textContent=selfState.role==='impostor'?'内鬼':'船员';roleRevealName.className=selfState.role==='impostor'?'impostor':'crewmate';roleRevealDesc.textContent=selfState.role==='impostor'?'隐藏身份，淘汰船员直到人数占优。':'完成任务，找出并投出所有内鬼。';roleReveal.classList.add('show');setTimeout(()=>roleReveal.classList.remove('show'),3200);}
function openMeeting(msg){gameState.phase='meeting';gameState.meeting=msg.meeting||null;renderGameMeta();renderActions();meetingOverlay.classList.add('show');renderMeeting();clearInterval(meetingTickTimer);meetingTickTimer=setInterval(renderMeeting,250);}
function closeMeeting(){meetingOverlay.classList.remove('show');clearInterval(meetingTickTimer);meetingTickTimer=null;}
function renderMeeting(){const m=gameState.meeting;if(!m)return;const now=Date.now(),discussion=now<Number(m.discussionEndsAt||0),deadline=discussion?Number(m.discussionEndsAt):Number(m.votingEndsAt);meetingTimer.textContent=`${Math.max(0,Math.ceil((deadline-now)/1000))}s`;meetingTitle.textContent=discussion?'讨论阶段':'投票阶段';meetingBody.textContent=m.reasonText||'紧急会议';const voted=String(m.myVote||'');voteGrid.innerHTML=Object.values(players).filter(p=>p.alive).map(p=>`<button type="button" class="vote-card ${voted===p.id?'selected':''}" data-vote="${escapeHtml(p.id)}" ${discussion||!selfState.alive||voted?'disabled':''}><span class="color-dot" style="background:${escapeHtml(p.color)}"></span><span>${escapeHtml(p.name)}${p.id===myPlayerId?' · 你':''}</span></button>`).join('');voteGrid.querySelectorAll('[data-vote]').forEach(btn=>btn.onclick=()=>castVote(btn.dataset.vote));skipVoteBtn.disabled=discussion||!selfState.alive||!!voted;skipVoteBtn.classList.toggle('selected',voted==='skip');}
function castVote(target){if(gameState.phase!=='meeting'||gameState.meeting?.myVote)return;if(sendPacket({t:'vote',target}))gameState.meeting.myVote=target;renderMeeting();}
function showEnd(msg){gameState.phase='ended';gameState.winner=msg.winner||'';gameState.reason=msg.reason||'';closeMeeting();renderGameMeta();renderActions();const crew=msg.winner==='crewmate';endTitle.textContent=crew?'船员胜利':'内鬼胜利';endTitle.className=crew?'crew-win':'imp-win';endReason.textContent=msg.reason||'';endOverlay.classList.add('show');}
function hideEnd(){endOverlay.classList.remove('show');}

function openTask(task){if(!task)return;activeTaskId=task.id;taskHoldStart=0;taskMeterFill.style.width='0%';taskModalTitle.textContent=task.label;taskModal.classList.add('show');keys={};resetJoy();}
function closeTask(){activeTaskId='';taskHoldStart=0;cancelAnimationFrame(taskHoldRAF);taskModal.classList.remove('show');taskMeterFill.style.width='0%';}
function tickTaskHold(){if(!taskHoldStart||!activeTaskId)return;const pct=clamp((performance.now()-taskHoldStart)/1300,0,1);taskMeterFill.style.width=`${pct*100}%`;if(pct>=1){const id=activeTaskId;closeTask();sendPacket({t:'task',id});return;}taskHoldRAF=requestAnimationFrame(tickTaskHold);}
function beginTaskHold(e){e?.preventDefault();if(!activeTaskId||taskHoldStart)return;taskHoldStart=performance.now();tickTaskHold();}
function endTaskHold(e){e?.preventDefault();if(!taskHoldStart)return;taskHoldStart=0;cancelAnimationFrame(taskHoldRAF);taskMeterFill.style.width='0%';}

function handleServerMessage(data){let msg;try{msg=JSON.parse(data);}catch(_){return;}if(!msg||typeof msg.t!=='string')return;
  if(msg.t==='welcome'){
    currentRoom=String(msg.room||currentRoom);myPlayerId=String(msg.self?.id||'');resumeToken=String(msg.self?.token||'');saveResumeToken(currentRoom,resumeToken);
    players=normalizePlayers(msg.players);if(players[myPlayerId]){myPos={...players[myPlayerId].pos};myName=players[myPlayerId].name;}
    isHost=String(msg.hostId||'')===myPlayerId;for(const p of Object.values(players))p.isHost=p.id===String(msg.hostId||'');
    gameState={...gameState,...(msg.game||{}),meeting:msg.game?.meeting||null};selfState={...selfState,...(msg.selfState||{})};bodies=Array.isArray(msg.bodies)?msg.bodies:[];
    seedRemoteVisuals();reconnectAttempts=0;lastPongAt=Date.now();setConnectionState('online','已连接');enterGame();if(gameState.phase==='meeting')openMeeting({meeting:gameState.meeting});if(gameState.phase==='ended')showEnd(gameState);
    if(connectResolve)connectResolve();clearTimeout(connectTimeout);connectTimeout=null;connectResolve=null;connectReject=null;if(msg.resumed)showToast('连接已恢复');return;
  }
  if(msg.t==='state'){
    const next=normalizePlayers(msg.players);if(next[myPlayerId])next[myPlayerId].pos={...myPos};players=next;for(const id of Object.keys(remoteVisuals))if(!players[id])delete remoteVisuals[id];for(const p of Object.values(players))if(p.id!==myPlayerId)retargetRemote(p.id,p.pos.x,p.pos.y);
    isHost=!!players[myPlayerId]?.isHost;if(msg.game)gameState={...gameState,...msg.game};if(msg.selfState)selfState={...selfState,...msg.selfState};if(Array.isArray(msg.bodies))bodies=msg.bodies;renderAllUI();return;
  }
  if(msg.t==='pos'){const id=String(msg.id||'');const x=Number(msg.x),y=Number(msg.y);if(!id||id===myPlayerId||!Number.isFinite(x)||!Number.isFinite(y))return;if(players[id]){players[id].pos={x,y};players[id].alive=msg.alive!==false;}retargetRemote(id,x,y);return;}
  if(msg.t==='correct'){const x=Number(msg.x),y=Number(msg.y);if(Number.isFinite(x)&&Number.isFinite(y)){myPos={x,y};if(players[myPlayerId])players[myPlayerId].pos={...myPos};posDirty=false;}return;}
  if(msg.t==='game_start'){gameState={...gameState,...msg.game,phase:'playing',meeting:null};selfState={...selfState,...msg.selfState};bodies=[];if(players[myPlayerId])players[myPlayerId].alive=true;hideEnd();closeMeeting();renderAllUI();showRoleReveal();return;}
  if(msg.t==='task_done'){selfState.completed=Array.isArray(msg.completed)?msg.completed:selfState.completed;gameState.taskDone=Number(msg.taskDone||0);gameState.taskTotal=Number(msg.taskTotal||0);renderGameMeta();renderActions();showToast('任务完成');return;}
  if(msg.t==='task_progress'){gameState.taskDone=Number(msg.taskDone||0);gameState.taskTotal=Number(msg.taskTotal||0);renderGameMeta();return;}
  if(msg.t==='killed'){selfState.alive=false;if(players[myPlayerId])players[myPlayerId].alive=false;showToast('你被击杀了',2400);renderAllUI();return;}
  if(msg.t==='kill_ok'){selfState.killReadyAt=Number(msg.killReadyAt||0);renderActions();return;}
  if(msg.t==='bodies'){bodies=Array.isArray(msg.bodies)?msg.bodies:[];renderActions();return;}
  if(msg.t==='meeting') {gameState.meeting=msg.meeting;openMeeting(msg);return;}
  if(msg.t==='meeting_result'){showToast(msg.text||'投票结束',2200);return;}
  if(msg.t==='resume_play'){gameState.phase='playing';gameState.meeting=null;selfState={...selfState,...(msg.selfState||{})};players=normalizePlayers(msg.players||players);if(players[myPlayerId])myPos={...players[myPlayerId].pos};bodies=[];seedRemoteVisuals();closeMeeting();renderAllUI();return;}
  if(msg.t==='game_over'){selfState={...selfState,...(msg.selfState||{})};showEnd(msg);return;}
  if(msg.t==='lobby_reset'){gameState={phase:'lobby',winner:'',reason:'',taskDone:0,taskTotal:0,meeting:null};selfState={role:'',alive:true,tasks:[],completed:[],killReadyAt:0,emergencyUsed:0};players=normalizePlayers(msg.players||players);bodies=[];hideEnd();closeMeeting();renderAllUI();return;}
  if(msg.t==='chat'){addMessage(msg.name,msg.text,msg.at);return;}
  if(msg.t==='notice'){showLeaveNotice(String(msg.text||''));return;}
  if(msg.t==='pong'){lastPongAt=Date.now();return;}
  if(msg.t==='kicked'){intentionalClose=true;showToast('你已被房主移出房间',2200);setTimeout(()=>leaveGame(false,'你已被房主移出房间'),500);return;}
  if(msg.t==='error'){const code=String(msg.code||''),text=String(msg.message||'连接失败');if(code==='resume_invalid'&&currentRoom){clearResumeToken(currentRoom);resumeToken='';if(socket){intentionalClose=true;try{socket.close();}catch(_){}}setTimeout(()=>{intentionalClose=false;connectRoom(currentRoom,false,true).catch(()=>{});},100);return;}if(connectReject){connectReject(new Error(text));clearTimeout(connectTimeout);connectResolve=null;connectReject=null;}setMenuStatus(text,'error');setConnectionState('error','连接失败');showToast(text,2200);if(code==='room_not_found'||code==='room_closed')setTimeout(()=>leaveGame(false,text),600);return;}
}

function connectRoom(room,create=false,reconnect=false){room=String(room).replace(/\D/g,'').slice(0,6);if(!/^\d{6}$/.test(room))return Promise.reject(new Error('房间号格式错误'));currentRoom=room;if(!resumeToken)resumeToken=loadResumeToken(room);intentionalClose=false;const generation=++socketGeneration;if(socket){try{socket.onclose=null;socket.close();}catch(_){}}setConnectionState('connecting',reconnect?'重连中':'连接中');if(!reconnect)setMenuStatus(create?'正在创建房间…':'正在加入房间…');const params=new URLSearchParams({room,name:myName,create:create?'1':'0',v:'2.0'});if(resumeToken)params.set('token',resumeToken);const ws=new WebSocket(`${REALTIME_ORIGIN}/ws?${params}`);socket=ws;return new Promise((resolve,reject)=>{connectResolve=resolve;connectReject=reject;connectTimeout=setTimeout(()=>{if(generation!==socketGeneration)return;try{ws.close();}catch(_){}reject(new Error('连接超时，请稍后重试'));connectResolve=null;connectReject=null;},10000);ws.onopen=()=>{if(generation!==socketGeneration)return;lastPongAt=Date.now();startHeartbeat();};ws.onmessage=e=>{if(generation===socketGeneration)handleServerMessage(e.data);};ws.onerror=()=>{};ws.onclose=()=>{if(generation!==socketGeneration)return;stopHeartbeat();if(connectReject){const r=connectReject;clearTimeout(connectTimeout);connectResolve=null;connectReject=null;r(new Error('无法连接到实时服务器'));}if(!intentionalClose&&currentRoom&&game.style.display!=='none')scheduleReconnect();else if(!intentionalClose&&menu.style.display!=='none')setConnectionState('error','连接失败');};});}
function scheduleReconnect(){clearTimeout(reconnectTimer);reconnectAttempts++;const delay=Math.min(8000,500*Math.pow(2,Math.min(reconnectAttempts-1,4)));setConnectionState('connecting',`重连中 ${reconnectAttempts}`);showToast('连接中断，正在自动恢复…',1400);reconnectTimer=setTimeout(async()=>{if(intentionalClose||!currentRoom)return;try{await connectRoom(currentRoom,false,true);}catch(_){if(!intentionalClose)scheduleReconnect();}},delay);}
async function createRoom(){createBtn.disabled=joinBtn.disabled=true;resumeToken='';for(let i=0;i<5;i++){const room=generateRoomId();try{await connectRoom(room,true,false);createBtn.disabled=joinBtn.disabled=false;return;}catch(err){if(!String(err.message).includes('已存在')){setMenuStatus(err.message,'error');break;}}}createBtn.disabled=joinBtn.disabled=false;}
async function joinRoom(room){createBtn.disabled=joinBtn.disabled=true;resumeToken=loadResumeToken(room);try{await connectRoom(room,false,false);}catch(err){setMenuStatus(err.message,'error');}createBtn.disabled=joinBtn.disabled=false;}
function leaveGame(sendLeave=true,menuText='已退出房间'){intentionalClose=true;clearTimeout(reconnectTimer);reconnectTimer=null;stopHeartbeat();if(sendLeave)sendPacket({t:'leave'});if(socket)try{socket.close(1000,'leave');}catch(_){}socket=null;if(currentRoom)clearResumeToken(currentRoom);currentRoom='';resumeToken='';myPlayerId='';players={};remoteVisuals={};isHost=false;bodies=[];gameState={phase:'lobby',winner:'',reason:'',taskDone:0,taskTotal:0,meeting:null};selfState={role:'',alive:true,tasks:[],completed:[],killReadyAt:0,emergencyUsed:0};keys={};resetJoy();messages=[];closeMeeting();hideEnd();closeTask();toggleChat(false);togglePlayerPanel(false);showMenu();setConnectionState('offline','离线');setMenuStatus(menuText);}

function update(dt){dt=clamp(dt,0,0.05);if(!socket||socket.readyState!==WebSocket.OPEN||!myPlayerId)return;renderActions();if(gameState.phase!=='playing')return;let dx=0,dy=0;if(keys.ArrowUp||keys.w||keys.W)dy-=1;if(keys.ArrowDown||keys.s||keys.S)dy+=1;if(keys.ArrowLeft||keys.a||keys.A)dx-=1;if(keys.ArrowRight||keys.d||keys.D)dx+=1;if(joyActive){dx+=joyDX;dy+=joyDY;}const mag=Math.hypot(dx,dy);if(mag>1){dx/=mag;dy/=mag;}if(Math.abs(dx)>0.001||Math.abs(dy)>0.001){const step=MOVE_SPEED*dt,nx=clamp(myPos.x+dx*step,PLAYER_RADIUS,MAP_SIZE-PLAYER_RADIUS);if(!selfState.alive||!circleHitsWall(nx,myPos.y))myPos.x=nx;const ny=clamp(myPos.y+dy*step,PLAYER_RADIUS,MAP_SIZE-PLAYER_RADIUS);if(!selfState.alive||!circleHitsWall(myPos.x,ny))myPos.y=ny;if(players[myPlayerId])players[myPlayerId].pos={...myPos};posDirty=true;}if(posDirty&&performance.now()-lastPosSendTime>=POS_SEND_INTERVAL){sendPacket({t:'pos',x:+myPos.x.toFixed(3),y:+myPos.y.toFixed(3)});lastPosSendTime=performance.now();posDirty=false;}}
function getCanvasPalette(){const dark=(document.documentElement.dataset.theme||'dark')==='dark';return dark?{floor:'#11151a',grid:'#171c22',wall:'#2b323b',wallEdge:'#3b4551',text:'#f3f4f6',muted:'#9ca3af',object:'#d1d5db',task:'#60a5fa',danger:'#ef4444',body:'#f8fafc',labelShadow:'rgba(0,0,0,.75)',outside:'#07090b'}:{floor:'#f5f6f7',grid:'#e6e9ed',wall:'#b8c0ca',wallEdge:'#9da7b4',text:'#111827',muted:'#667085',object:'#475467',task:'#2563eb',danger:'#dc2626',body:'#111827',labelShadow:'rgba(255,255,255,.9)',outside:'#dfe3e8'};}
function resizeCanvas(){const dpr=Math.min(devicePixelRatio||1,2),rect=canvas.getBoundingClientRect(),w=Math.max(1,Math.round(rect.width)),h=Math.max(1,Math.round(rect.height));canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);canvas._cssWidth=w;canvas._cssHeight=h;}
function drawMap(view,p){const{left,top,side,tilePx,cameraX,cameraY}=view;ctx.fillStyle=p.outside;ctx.fillRect(0,0,canvas._cssWidth,canvas._cssHeight);ctx.fillStyle=p.floor;ctx.fillRect(left,top,side,side);ctx.save();ctx.beginPath();ctx.rect(left,top,side,side);ctx.clip();const minC=Math.max(0,Math.floor(cameraX-VIEW_TILES/2)-1),maxC=Math.min(MAP_SIZE-1,Math.ceil(cameraX+VIEW_TILES/2)+1),minR=Math.max(0,Math.floor(cameraY-VIEW_TILES/2)-1),maxR=Math.min(MAP_SIZE-1,Math.ceil(cameraY+VIEW_TILES/2)+1);for(let row=minR;row<=maxR;row++)for(let col=minC;col<=maxC;col++){const sx=left+(col-(cameraX-VIEW_TILES/2))*tilePx,sy=top+(row-(cameraY-VIEW_TILES/2))*tilePx;if(isWallCell(col,row)){ctx.fillStyle=p.wall;ctx.fillRect(sx,sy,tilePx+.5,tilePx+.5);ctx.strokeStyle=p.wallEdge;ctx.lineWidth=1;ctx.strokeRect(sx+.5,sy+.5,tilePx-1,tilePx-1);}else if(tilePx>=20){ctx.strokeStyle=p.grid;ctx.strokeRect(sx,sy,tilePx,tilePx);}}
  for(const o of OBJECT_DEFS){if(Math.abs(o.x-cameraX)>11||Math.abs(o.y-cameraY)>11)continue;const sx=left+(o.x-(cameraX-VIEW_TILES/2))*tilePx,sy=top+(o.y-(cameraY-VIEW_TILES/2))*tilePx;const assigned=selfState.role==='crewmate'&&selfState.tasks.includes(o.id)&&!selfState.completed.includes(o.id);ctx.fillStyle=assigned?p.task:p.object;ctx.fillRect(sx-tilePx*.23,sy-tilePx*.23,tilePx*.46,tilePx*.46);if(o.id===EMERGENCY_STATION&&selfState.alive&&selfState.emergencyUsed===0){ctx.strokeStyle=p.danger;ctx.lineWidth=2;ctx.strokeRect(sx-tilePx*.31,sy-tilePx*.31,tilePx*.62,tilePx*.62);}if(assigned&&dist(myPos,o)<1.8){ctx.font=`500 ${Math.max(11,tilePx*.25)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='bottom';ctx.fillStyle=p.text;ctx.fillText(o.label,sx,sy-tilePx*.42);}}
  for(const b of bodies){if(Math.abs(b.x-cameraX)>11||Math.abs(b.y-cameraY)>11)continue;const x=left+(b.x-(cameraX-VIEW_TILES/2))*tilePx,y=top+(b.y-(cameraY-VIEW_TILES/2))*tilePx;ctx.save();ctx.translate(x,y);ctx.fillStyle=b.color||p.body;ctx.beginPath();ctx.arc(-tilePx*.12,0,tilePx*.18,0,Math.PI*2);ctx.arc(tilePx*.12,0,tilePx*.18,0,Math.PI*2);ctx.fill();ctx.strokeStyle=p.danger;ctx.lineWidth=Math.max(2,tilePx*.05);ctx.beginPath();ctx.moveTo(0,-tilePx*.18);ctx.lineTo(0,tilePx*.18);ctx.stroke();ctx.restore();}
  ctx.restore();}
function drawPlayers(view,p){const{left,top,tilePx,cameraX,cameraY}=view;for(const pl of Object.values(players)){if(!pl.connected)continue;if(!pl.alive&&selfState.alive&&pl.id!==myPlayerId)continue;const visual=remoteVisuals[pl.id],pos=pl.id===myPlayerId?myPos:(visual?{x:visual.x,y:visual.y}:pl.pos);if(!pos||Math.abs(pos.x-cameraX)>11||Math.abs(pos.y-cameraY)>11)continue;const x=left+(pos.x-(cameraX-VIEW_TILES/2))*tilePx,y=top+(pos.y-(cameraY-VIEW_TILES/2))*tilePx,r=PLAYER_RADIUS*tilePx;ctx.save();if(!pl.alive)ctx.globalAlpha=.38;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fillStyle=pl.color;ctx.fill();ctx.lineWidth=Math.max(1.5,tilePx*.07);ctx.strokeStyle=pl.id===myPlayerId?p.text:'rgba(0,0,0,.28)';ctx.stroke();ctx.font=`600 ${Math.max(11,tilePx*.27)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='bottom';ctx.fillStyle=p.text;ctx.shadowColor=p.labelShadow;ctx.shadowBlur=3;ctx.fillText(`${pl.name}${pl.id===myPlayerId?' · 你':''}`,x,y-r-5);ctx.restore();}}
function draw(){const W=canvas._cssWidth||innerWidth,H=canvas._cssHeight||innerHeight,side=Math.min(W,H),left=(W-side)/2,top=(H-side)/2,tilePx=side/VIEW_TILES,cameraX=clamp(myPos.x,VIEW_TILES/2,MAP_SIZE-VIEW_TILES/2),cameraY=clamp(myPos.y,VIEW_TILES/2,MAP_SIZE-VIEW_TILES/2),view={left,top,side,tilePx,cameraX,cameraY},p=getCanvasPalette();ctx.clearRect(0,0,W,H);drawMap(view,p);drawPlayers(view,p);}
function gameLoop(now=performance.now()){if(!window._gameLoopRunning)return;const dt=(now-lastFrameTime)/1000;lastFrameTime=now;update(dt);updateRemoteVisuals(dt);draw();requestAnimationFrame(gameLoop);}

function handleJoyTouch(clientX,clientY){const rect=joystick.getBoundingClientRect(),cx=rect.left+rect.width/2,cy=rect.top+rect.height/2,dx=clientX-cx,dy=clientY-cy,maxR=Math.max(1,rect.width/2-20),d=Math.hypot(dx,dy),scale=Math.min(1,d/maxR),a=Math.atan2(dy,dx),kx=Math.cos(a)*maxR*scale,ky=Math.sin(a)*maxR*scale;joystickKnob.style.transform=`translate(calc(-50% + ${kx}px), calc(-50% + ${ky}px))`;joyDX=Math.cos(a)*scale;joyDY=Math.sin(a)*scale;joyActive=d>2;}
function resetJoy(){joyActive=false;joyDX=0;joyDY=0;joystickKnob.style.transform='translate(-50%, -50%)';}

window.addEventListener('keydown',e=>{if(document.activeElement!==chatInput)keys[e.key]=true;});window.addEventListener('keyup',e=>{keys[e.key]=false;});window.addEventListener('blur',()=>{keys={};resetJoy();});window.addEventListener('resize',()=>{checkOrientation();resizeCanvas();});window.addEventListener('orientationchange',()=>setTimeout(()=>{checkOrientation();resizeCanvas();},150));document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&currentRoom&&(!socket||socket.readyState!==WebSocket.OPEN)&&!intentionalClose)scheduleReconnect();});
joystick.addEventListener('touchstart',e=>{e.preventDefault();if(e.touches[0])handleJoyTouch(e.touches[0].clientX,e.touches[0].clientY);},{passive:false});joystick.addEventListener('touchmove',e=>{e.preventDefault();if(e.touches[0])handleJoyTouch(e.touches[0].clientX,e.touches[0].clientY);},{passive:false});joystick.addEventListener('touchend',e=>{e.preventDefault();resetJoy();},{passive:false});joystick.addEventListener('touchcancel',resetJoy);joystick.addEventListener('mousedown',e=>{mouseDown=true;handleJoyTouch(e.clientX,e.clientY);});window.addEventListener('mousemove',e=>{if(mouseDown)handleJoyTouch(e.clientX,e.clientY);});window.addEventListener('mouseup',()=>{if(mouseDown){mouseDown=false;resetJoy();}});

createBtn.onclick=async()=>{myName=sanitizeName(nameInput.value);nameInput.value=myName;await createRoom();};showJoinBtn.onclick=()=>{joinVisible=!joinVisible;joinSection.style.display=joinVisible?'block':'none';showJoinBtn.textContent=joinVisible?'取消':'加入房间';if(joinVisible)roomIdInput.focus();};joinBtn.onclick=async()=>{const room=roomIdInput.value.trim();if(!/^\d{6}$/.test(room)){setMenuStatus('请输入 6 位数字房间号','error');return;}myName=sanitizeName(nameInput.value);nameInput.value=myName;await joinRoom(room);};roomIdInput.onkeydown=e=>{if(e.key==='Enter')joinBtn.click();};nameInput.onkeydown=e=>{if(e.key==='Enter')createBtn.click();};leaveBtn.onclick=()=>{if(confirm('确定要退出房间吗？'))leaveGame(true);};chatToggle.onclick=()=>toggleChat();chatPanelClose.onclick=()=>toggleChat(false);chatSend.onclick=()=>sendChatMessage(chatInput.value);chatInput.onkeydown=e=>{if(e.key==='Enter')sendChatMessage(chatInput.value);};chatInput.onfocus=()=>{keys={};};playerCountBtn.onclick=()=>togglePlayerPanel();playerPanelClose.onclick=()=>togglePlayerPanel(false);settingsBtn.onclick=toggleTheme;menuThemeBtn.onclick=toggleTheme;roomIdDisplay.onclick=async()=>{try{await navigator.clipboard.writeText(currentRoom);showToast('房间号已复制');}catch(_){showToast(`房间号 ${currentRoom}`);}};
startGameBtn.onclick=()=>sendPacket({t:'start'});reportBtn.onclick=()=>{const b=nearestBody();if(b)sendPacket({t:'report',bodyId:b.id});};killBtn.onclick=()=>{const t=nearestKillTarget();if(t)sendPacket({t:'kill',targetId:t.id});};interactBtn.onclick=()=>{const task=nearestAssignedTask();if(task){openTask(task);return;}if(canEmergency())sendPacket({t:'emergency'});};skipVoteBtn.onclick=()=>castVote('skip');backLobbyBtn.onclick=()=>{if(isHost)sendPacket({t:'reset'});else showToast('等待房主返回大厅');};taskHoldBtn.addEventListener('pointerdown',beginTaskHold);taskHoldBtn.addEventListener('pointerup',endTaskHold);taskHoldBtn.addEventListener('pointerleave',endTaskHold);taskHoldBtn.addEventListener('pointercancel',endTaskHold);taskCancelBtn.onclick=closeTask;
document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(taskModal.classList.contains('show'))closeTask();else if(chatVisible)toggleChat(false);else if(playerPanelVisible)togglePlayerPanel(false);}});

const defaultName='玩家'+Math.floor(Math.random()*1000);nameInput.value=defaultName;myName=defaultName;showMenu();setMenuStatus('输入昵称，然后创建或加入房间');setConnectionState('offline','离线');resizeCanvas();checkOrientation();interactBtn.disabled=true;reportBtn.disabled=true;killBtn.disabled=true;
console.log('Among Us 东滩版 2.0 · gameplay complete');
})();
